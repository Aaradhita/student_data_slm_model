# Quick Reference Guide & Implementation Checklist

## 📋 Complete Implementation Checklist

### **PHASE 1: Authentication & Security** ⏱️ Week 1-2

#### Step 1.1: Create Password & Authentication Utilities
- [ ] Create `auth/password_utils.py`
  - Hash password using bcrypt
  - Verify password function
  - Generate secure tokens
  
- [ ] Create `auth/models.py`
  - User data model
  - Token payload model
  - Login request/response models

#### Step 1.2: Build Authentication Service
- [ ] Create `auth/auth_service.py`
  - Login function (verify credentials)
  - JWT token generation
  - Token validation
  - Token refresh logic

#### Step 1.3: Add Authentication Middleware
- [ ] Create `auth/middleware.py`
  - Extract token from header
  - Verify token signature
  - Check token expiration
  - Verify user ownership of data

#### Step 1.4: Update Database for Users
- [ ] Modify `database/db_init.py`
  - Add users table with password_hash
  - Add chat_history table
  - Add access_log table

#### Step 1.5: Create Login API Endpoint
- [ ] Update `stage5_chat_api.py`
  - Add POST /api/v2/auth/login endpoint
  - Add POST /api/v2/auth/logout endpoint
  - Add GET /api/v2/auth/me endpoint

#### Step 1.6: Design & Create Login Page
- [ ] Create `frontend/login.html`
  - Professional gradient background
  - Centered login form
  - Register number input
  - Password input
  - Login button
  - Error message display
  - Remember me checkbox
  - Responsive design

#### Step 1.7: Create Frontend Auth Logic
- [ ] Create `frontend/js/auth.js`
  - Handle login form submission
  - Send credentials to API
  - Store JWT token in localStorage
  - Redirect to dashboard on success
  - Show error on failure
  - Handle logout

---

### **PHASE 2: Dynamic Dataset System** ⏱️ Week 2-3

#### Step 2.1: Create Dataset Detection Module
- [ ] Create `config/dataset_config.py`
  - Read CSV file
  - Auto-detect column names
  - Auto-detect data types
  - Identify primary key
  - Mark sensitive columns
  - Generate configuration JSON

#### Step 2.2: Create Configuration Files
- [ ] Create `config/dataset_config.json` (template)
  ```json
  {
    "dataset_name": "students_2024",
    "file_path": "data/students.csv",
    "primary_key": "Register_Number",
    "columns": {...},
    "sensitive_columns": [],
    "display_columns": [],
    "intents": {}
  }
  ```

#### Step 2.3: Refactor Database Initialization
- [ ] Refactor `database/db_init.py`
  - Read dataset_config.json
  - Dynamically create table schema
  - Support any column names/types
  - Auto-create indexes

#### Step 2.4: Create Database Utilities
- [ ] Update `database/db_utils.py`
  - Generic get_record function
  - Get specific column value
  - Query by column name
  - Support dynamic columns

#### Step 2.5: Create Admin Endpoint for Dataset Upload
- [ ] Update `stage5_chat_api.py`
  - POST /api/v2/admin/dataset/upload
  - Validate CSV file
  - Call dataset detection
  - Create database
  - Load data

---

### **PHASE 3: Dynamic Intent System** ⏱️ Week 3-4

#### Step 3.1: Create Intent Generator
- [ ] Create `intent/intent_generator.py`
  - For each dataset column:
    - Generate 10-15 query variations
    - Support multiple intent types
    - Create training data CSV
  
  ```python
  # Example: For column "Fees_Details"
  [
    "show me my Fees_Details",
    "what are my Fees_Details",
    "get Fees_Details information",
    "Fees_Details status",
    "tell me about Fees_Details",
    "my Fees_Details please",
    # ... more variations
  ]
  ```

#### Step 3.2: Upgrade Intent Classifier
- [ ] Create `intent/intent_classifier_v2.py`
  - Use sentence-transformers library
  - Load pre-trained model: 'all-MiniLM-L6-v2'
  - Compute embeddings for training data
  - Predict intent using cosine similarity
  - Return confidence score
  
  ```python
  from sentence_transformers import SentenceTransformer
  
  class SemanticIntentClassifier:
      def __init__(self, training_queries, intents):
          self.model = SentenceTransformer('all-MiniLM-L6-v2')
          self.training_embeddings = self.model.encode(training_queries)
          self.intents = intents
      
      def predict_intent(self, query):
          query_embedding = self.model.encode([query])
          similarities = cosine_similarity(query_embedding, 
                                          self.training_embeddings)[0]
          best_idx = similarities.argmax()
          return self.intents[best_idx], similarities[best_idx]
  ```

#### Step 3.3: Create Intent Mapping System
- [ ] Create `intent/intent_mapper.py`
  - Map intent → column name
  - Handle synonyms
  - Support alias resolution
  
  ```python
  # Example mapping:
  {
    "query_type": "column_query",
    "intent_keywords": ["fees", "fee", "payment", "charges"],
    "target_column": "Fees_Details",
    "response_template": "Your fees are: {value}"
  }
  ```

#### Step 3.4: Create Intent Templates Config
- [ ] Create `config/intent_templates.json`
  - Predefined intent patterns
  - Query templates
  - Response formats

#### Step 3.5: Update Intent Classifier Endpoint
- [ ] Update `stage5_chat_api.py`
  - Replace old keyword detection
  - Use new semantic classifier
  - Return confidence scores
  - Log intent predictions

---

### **PHASE 4: Dynamic API Endpoints** ⏱️ Week 4

#### Step 4.1: Create Query Handler
- [ ] Create `api/query_handler.py`
  - Parse natural language query
  - Call intent classifier
  - Map to column
  - Validate access
  - Execute DB query
  - Format response

#### Step 4.2: Create Generic Data Endpoint
- [ ] Update `stage3_api.py`
  - Replace hardcoded endpoints
  - Create generic GET /user/data/{column} endpoint
  - Support POST /user/query with natural language
  - Validate token for each request
  - Check data ownership

#### Step 4.3: Add Access Control Middleware
- [ ] Update `auth/middleware.py`
  - Verify token on every request
  - Extract user_id from token
  - Check if user can access requested column
  - Verify column exists in dataset
  - Log access attempt

#### Step 4.4: Create Admin API Endpoints
- [ ] Create `api/admin_endpoints.py`
  - GET /api/v2/admin/datasets (list all)
  - GET /api/v2/admin/dataset/{id} (metadata)
  - DELETE /api/v2/admin/dataset/{id} (remove)
  - POST /api/v2/admin/users (manage users)

#### Step 4.5: Implement Audit Logging
- [ ] Create `utils/audit_logger.py`
  - Log all data access
  - Log failed access attempts
  - Log login/logout
  - Timestamp every event
  - Include user_id, IP, action

---

### **PHASE 5: Enhanced UI/UX** ⏱️ Week 5

#### Step 5.1: Redesign Dashboard
- [ ] Create `frontend/pages/dashboard.html`
  - User profile card
  - Quick statistics
  - Suggested queries
  - Recent chat history
  - Settings link
  - Logout button
  
  Layout:
  ```
  ┌────────────────────────────┐
  │ Header: Logo | Settings | Logout
  ├────────────────────────────┤
  │ [Profile Card]  [Chat Box] │
  │ • Name          Recent:    │
  │ • Reg #         • Query 1  │
  │ • Stats         • Query 2  │
  │                 Input:     │
  │ [Suggestions]   [       ]  │
  │ • Show CGPA     [Send]     │
  │ • Show Attend..│            │
  │ • Show Fees     │            │
  └────────────────────────────┘
  ```

#### Step 5.2: Create Stylesheet
- [ ] Create `frontend/css/styles.css`
  - Modern color scheme
  - Responsive grid layout
  - Card styling
  - Button styles
  - Chat message bubbles
  - Form inputs
  - Dark mode support
  
  ```css
  /* Color Scheme */
  --primary: #6366F1     /* Indigo */
  --secondary: #8B5CF6   /* Purple */
  --success: #10B981     /* Green */
  --danger: #EF4444      /* Red */
  --bg: #F9FAFB          /* Light */
  --text: #1F2937        /* Dark */
  
  /* Responsive Breakpoints */
  Mobile: 320px - 640px
  Tablet: 641px - 1024px
  Desktop: 1025px+
  ```

#### Step 5.3: Enhance Chat Interface
- [ ] Update `templates/chat.html`
  - Better message formatting
  - User vs bot message bubbles
  - Typing indicator
  - Error messages
  - Success messages
  - Timestamp on messages
  - Message history sidebar

#### Step 5.4: Add Data Visualization
- [ ] Create `frontend/js/charts.js`
  - Use Chart.js library
  - Line chart for attendance trends
  - Pie chart for fee breakdown
  - Progress bars for CGPA
  - Comparison charts

#### Step 5.5: Create Profile Page
- [ ] Create `frontend/pages/profile.html`
  - User information
  - Edit profile (if allowed)
  - Change password
  - Download transcript
  - Privacy settings
  - Account activity log

#### Step 5.6: Improve Mobile Experience
- [ ] Update all templates for mobile
  - Touch-friendly buttons
  - Readable text size
  - Full-width design
  - Collapse navigation
  - Swipe support

---

### **PHASE 6: Advanced Features** ⏱️ Week 6

#### Step 6.1: Multi-Column Queries
- [ ] Update `intent/intent_classifier_v2.py`
  - Detect multiple intents in one query
  - Support: "Show my fees, attendance, and CGPA"
  - Fetch multiple columns
  - Format response with multiple fields

#### Step 6.2: Comparative Analytics
- [ ] Create `api/analytics_endpoints.py`
  - Class average (anonymized)
  - Attendance trends
  - Grade distributions
  - Comparison with class
  - Note: Only show aggregated data, no individual names

#### Step 6.3: Admin Dashboard
- [ ] Create `frontend/pages/admin_dashboard.html`
  - User management
  - Dataset management
  - System statistics
  - Access logs viewer
  - Intent usage statistics

#### Step 6.4: Export Functionality
- [ ] Create `utils/export_utils.py`
  - Export chat as PDF
  - Export transcript as PDF
  - Download as CSV (own data only)
  - Email transcript

#### Step 6.5: Testing Suite
- [ ] Create `tests/test_auth.py`
- [ ] Create `tests/test_api.py`
- [ ] Create `tests/test_intent.py`
- [ ] Create `tests/test_database.py`

---

## 🔧 Code Templates to Use

### **Template 1: Protected API Endpoint**
```python
from fastapi import FastAPI, Depends, HTTPException
from auth.middleware import verify_token

app = FastAPI()

@app.get("/api/v2/user/data/{column}")
async def get_user_data(column: str, token_data: dict = Depends(verify_token)):
    """
    Protected endpoint - requires JWT token
    Returns only the authenticated user's data
    """
    user_id = token_data["user_id"]
    
    # Get user's column data (privacy preserved)
    data = db_utils.get_user_column(user_id, column)
    
    if not data:
        raise HTTPException(status_code=404, detail="Column not found")
    
    # Log access for audit
    audit_logger.log_access(user_id, "column_access", column, "success")
    
    return {"column": column, "value": data}
```

### **Template 2: Dynamic Intent Detection**
```python
class DynamicIntentClassifier:
    def __init__(self, dataset_config):
        self.dataset_config = dataset_config
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Generate training queries from columns
        self.training_queries = []
        self.intent_labels = []
        
        for column in dataset_config['columns']:
            queries = self.generate_queries(column)
            self.training_queries.extend(queries)
            self.intent_labels.extend([column] * len(queries))
        
        # Compute embeddings once at startup
        self.embeddings = self.model.encode(self.training_queries)
    
    def generate_queries(self, column):
        """Generate query variations for a column"""
        return [
            f"show me my {column}",
            f"what is my {column}",
            f"get {column} information",
            f"{column} status",
            f"tell me about {column}",
            f"my {column} please",
            # ... more variations
        ]
    
    def predict(self, query):
        """Predict which column the user is asking about"""
        query_embedding = self.model.encode([query])
        similarities = cosine_similarity(query_embedding, self.embeddings)[0]
        best_idx = similarities.argmax()
        
        return {
            "column": self.intent_labels[best_idx],
            "confidence": float(similarities[best_idx])
        }
```

### **Template 3: Database Auto-Creation**
```python
def create_dynamic_database(csv_path, db_name, dataset_config):
    """
    Auto-create database table from CSV columns
    """
    import pandas as pd
    import sqlite3
    
    # Read CSV to understand structure
    df = pd.read_csv(csv_path)
    
    # Build CREATE TABLE statement
    columns_def = []
    for col_name in df.columns:
        col_type = infer_type(df[col_name])
        is_pk = "PRIMARY KEY" if col_name == dataset_config['primary_key'] else ""
        columns_def.append(f"{col_name} {col_type} {is_pk}".strip())
    
    # Create table
    create_table_sql = f"""
    CREATE TABLE IF NOT EXISTS {dataset_config['table_name']} (
        {', '.join(columns_def)}
    )
    """
    
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    cursor.execute(create_table_sql)
    
    # Load data from CSV
    for _, row in df.iterrows():
        placeholders = ', '.join(['?' for _ in df.columns])
        insert_sql = f"INSERT INTO {dataset_config['table_name']} VALUES ({placeholders})"
        cursor.execute(insert_sql, tuple(row))
    
    conn.commit()
    conn.close()

def infer_type(series):
    """Infer SQL type from pandas series"""
    if pd.api.types.is_integer_dtype(series):
        return "INTEGER"
    elif pd.api.types.is_float_dtype(series):
        return "REAL"
    else:
        return "TEXT"
```

### **Template 4: JWT Token Verification Middleware**
```python
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthCredentials
import jwt
from datetime import datetime

security = HTTPBearer()
SECRET_KEY = "your-secret-key"  # Use env variable in production

async def verify_token(credentials: HTTPAuthCredentials = Depends(security)) -> dict:
    """
    Middleware to verify JWT token
    Extracts and validates token claims
    """
    token = credentials.credentials
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        
        # Check expiration
        exp = payload.get("exp")
        if exp and datetime.fromtimestamp(exp) < datetime.utcnow():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        
        return payload
    
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate token"
        )
```

---

## 📦 Directory Structure to Create

```
project_final/
│
├── auth/
│   ├── __init__.py
│   ├── models.py
│   ├── auth_service.py
│   ├── password_utils.py
│   └── middleware.py
│
├── config/
│   ├── __init__.py
│   ├── dataset_config.py
│   ├── dataset_config.json
│   └── intent_templates.json
│
├── database/
│   ├── __init__.py
│   ├── db_init.py
│   ├── db_utils.py
│   └── migrations.py
│
├── intent/
│   ├── __init__.py
│   ├── intent_classifier_v2.py
│   ├── intent_generator.py
│   ├── intent_mapper.py
│   └── training_data.csv
│
├── api/
│   ├── __init__.py
│   ├── stage3_api.py (refactored)
│   ├── stage5_chat_api.py (refactored)
│   ├── query_handler.py
│   ├── admin_endpoints.py
│   └── analytics_endpoints.py
│
├── frontend/
│   ├── pages/
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   ├── chat.html
│   │   └── profile.html
│   ├── css/
│   │   ├── styles.css
│   │   └── chat-theme.css
│   └── js/
│       ├── auth.js
│       ├── chat.js
│       ├── charts.js
│       └── utils.js
│
├── utils/
│   ├── __init__.py
│   ├── validators.py
│   ├── audit_logger.py
│   ├── export_utils.py
│   └── helpers.py
│
├── tests/
│   ├── __init__.py
│   ├── test_auth.py
│   ├── test_api.py
│   ├── test_intent.py
│   └── test_database.py
│
├── templates/
│   └── chat.html (legacy, can be refactored)
│
├── stage4/
│   ├── build_index.py
│   ├── chat.py
│   ├── rag_pipeline.py
│   └── __pycache__/
│
├── .env.example
├── .gitignore
├── main.py
├── requirements.txt
├── requirements_full.txt
├── IMPROVEMENT_PLAN.md
├── IMPLEMENTATION_GUIDE.md
├── ARCHITECTURE.md
└── QUICK_REFERENCE.md (this file)
```

---

## ✅ Testing Checklist

### Authentication Tests
- [ ] Login with correct credentials → Success
- [ ] Login with wrong password → Fail
- [ ] Login with non-existent user → Fail
- [ ] Access endpoint without token → 401
- [ ] Access endpoint with invalid token → 401
- [ ] Access endpoint with expired token → 401
- [ ] User accessing other's data → 403

### Intent Classification Tests
- [ ] "show my fees" → Fees_Details column
- [ ] "What's my attendance?" → Attendance_Percentage
- [ ] "Tell me about my CGPA" → CGPA
- [ ] Varied phrasings → Same intent
- [ ] Multiple intents → Correct columns
- [ ] Unrelated query → Graceful fallback

### Database Tests
- [ ] Upload new CSV → Table created
- [ ] Auto-detect columns → Correct types
- [ ] Load data correctly → All rows inserted
- [ ] Query by column → Correct value returned
- [ ] Add new dataset → Parallel DB created
- [ ] Switch between datasets → Correct data

### API Tests
- [ ] GET /user/data/{column} → User's data only
- [ ] POST /user/query → Intent detected, data returned
- [ ] Audit log created → For every access
- [ ] Response format → Consistent & documented
- [ ] Error handling → Proper error codes

---

## 🚀 Deployment Checklist

- [ ] Use environment variables for secrets
- [ ] Enable HTTPS/SSL
- [ ] Set JWT token expiration (15 min access, 7 day refresh)
- [ ] Enable CORS for frontend domain only
- [ ] Implement rate limiting
- [ ] Add database backups
- [ ] Set up logging & monitoring
- [ ] Document all APIs
- [ ] Create user guide
- [ ] Test end-to-end flow
- [ ] Security audit
- [ ] Performance testing

---

## 📚 Dependencies to Add

```bash
# Authentication & Security
pip install PyJWT
pip install bcrypt
pip install python-multipart

# ML & NLP
pip install sentence-transformers
pip install scikit-learn
pip install torch

# Web Framework
pip install fastapi
pip install uvicorn
pip install python-jose

# Database
pip install sqlite3  # Built-in

# Data Processing
pip install pandas
pip install numpy

# Utilities
pip install python-dotenv
pip install requests
pip install Pillow

# Testing
pip install pytest
pip install pytest-asyncio

# Visualization (Optional)
pip install matplotlib
pip install plotly
```

---

## 💡 Pro Tips for Implementation

1. **Start with Phase 1 (Auth)** - Critical for security
2. **Test incrementally** - Don't wait for everything
3. **Use environment variables** - For API keys, DB paths, etc.
4. **Implement logging early** - Helps debug issues
5. **Use TypeScript/JSDoc** - For frontend, improves maintainability
6. **Document APIs** - Use FastAPI's automatic docs
7. **Cache intent embeddings** - Don't recompute every request
8. **Optimize DB queries** - Add indexes on frequently queried columns
9. **Version your APIs** - /api/v2/ allows future changes
10. **Backup user data** - Critical for production

---

## 🎯 Success Metrics

| Metric | Target |
|--------|--------|
| Intent Accuracy | >90% |
| Query Response Time | <500ms |
| Login Success Rate | >99% |
| System Availability | 99.5% uptime |
| User Satisfaction | >4.5/5 |
| Data Access Speed | <100ms |
| Error Rate | <0.1% |

---

**Ready to start coding?**
Begin with Phase 1: Authentication & Login System
Focus: Build a solid foundation for security
Estimated time: 3-4 days

