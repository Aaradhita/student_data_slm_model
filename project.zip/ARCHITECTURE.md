# Architecture Diagram & Visual Reference

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          USER INTERACTION LAYER                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌──────────────────┐      ┌──────────────────┐      ┌──────────────┐  │
│  │   Login Page     │      │   Dashboard      │      │   Chat UI    │  │
│  │                  │      │                  │      │              │  │
│  │ Register # ←────→│      │ Profile Stats    │      │ Messages     │  │
│  │ Password   │     │      │ Quick Actions    │←────→│ Suggestions  │  │
│  │ [Login]    │     │      │                  │      │ History      │  │
│  └──────────────────┘      └──────────────────┘      └──────────────┘  │
│         │                         │                         │           │
│         └─────────────────────────┼─────────────────────────┘           │
│                                   │                                      │
└───────────────────────────────────┼──────────────────────────────────────┘
                                    │
                            JWT Token Exchange
                                    │
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                       AUTHENTICATION LAYER                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  JWT Token Verification & User Authorization                     │  │
│  │                                                                   │  │
│  │  1. Verify token signature                                       │  │
│  │  2. Check token expiration                                       │  │
│  │  3. Validate user_id against requested data                      │  │
│  │  4. Check user permissions                                       │  │
│  │  5. Log access attempt                                           │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                       API & QUERY PROCESSING LAYER                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌──────────────────┐      ┌────────────────────┐      ┌─────────────┐ │
│  │  Intent         │      │  Column Mapper     │      │ Query       │ │
│  │  Classifier     │──→   │                    │──→   │ Handler     │ │
│  │                 │      │ Query → Column     │      │             │ │
│  │ Semantic        │      │ Resolution         │      │ DB Lookup   │ │
│  │ Matching        │      │                    │      │ & Response  │ │
│  └──────────────────┘      └────────────────────┘      └─────────────┘ │
│                                                                           │
│  "Show my fees" → Intent: column_query → Column: Fees_Details → Retrieve
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                      CONFIGURATION & DATA LAYER                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌─────────────────────┐      ┌──────────────────────────────────────┐  │
│  │   Config DB         │      │      Data Database(s)                │  │
│  │   (config.db)       │      │  (students_2024.db, etc)             │  │
│  │                     │      │                                       │  │
│  │ • Datasets          │      │  ┌──────────────────────────────────┐ │  │
│  │ • Column Defs       │      │  │ Users Table                      │ │  │
│  │ • Intent Mappings   │      │  │ - register_number (PK)           │ │  │
│  │ • Metadata          │      │  │ - password_hash                  │ │  │
│  │                     │      │  └──────────────────────────────────┘ │  │
│  │ Auto-generated from │      │                                       │  │
│  │ dataset CSV         │      │  ┌──────────────────────────────────┐ │  │
│  │                     │      │  │ Student Records Table            │ │  │
│  │                     │      │  │ (dynamic columns from CSV)       │ │  │
│  │                     │      │  │ - Auto-detected & created        │ │  │
│  │                     │      │  │ - Any columns supported          │ │  │
│  │                     │      │  └──────────────────────────────────┘ │  │
│  │                     │      │                                       │  │
│  │                     │      │  ┌──────────────────────────────────┐ │  │
│  │                     │      │  │ Chat History Table               │ │  │
│  │                     │      │  │ - query, intent, response        │ │  │
│  │                     │      │  │ - timestamp, user_id             │ │  │
│  │                     │      │  └──────────────────────────────────┘ │  │
│  │                     │      │                                       │  │
│  └─────────────────────┘      └──────────────────────────────────────┘  │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow - User Query Processing

```
                        USER ENTERS QUERY
                              │
                              ↓
                    ┌──────────────────────┐
                    │ User Authentication  │
                    │ Check JWT Token      │
                    └──────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
              VALID │                   │ INVALID
                    ↓                   ↓
            ┌─────────────┐      Return 401
            │ Proceed     │      Unauthorized
            └─────────────┘
                    │
                    ↓
          ┌──────────────────────┐
          │ Intent Classification │
          │ (Semantic Matching)   │
          │ Input: "show my fees" │
          │ Output: column_query  │
          └──────────────────────┘
                    │
                    ↓
          ┌──────────────────────┐
          │ Column Mapping       │
          │ Intent → Column      │
          │ column_query →       │
          │ Fees_Details         │
          └──────────────────────┘
                    │
                    ↓
          ┌──────────────────────┐
          │ Access Control       │
          │ Check if user owns   │
          │ this column data     │
          └──────────────────────┘
                    │
          ┌─────────┴─────────┐
          │                   │
       ALLOWED             DENIED
          │                 │
          ↓                 ↓
    ┌──────────────┐   Return 403
    │ DB Query     │   Forbidden
    │ Execute SQL  │
    └──────────────┘
          │
          ↓
    ┌──────────────┐
    │ Format       │
    │ Response     │
    └──────────────┘
          │
          ↓
    ┌──────────────┐
    │ Log Access   │
    │ (Audit Trail)│
    └──────────────┘
          │
          ↓
    RETURN RESPONSE
    TO USER
```

---

## Dynamic Dataset System Flow

```
┌────────────────────────────────────────────────────────────────────┐
│                        ADMIN UPLOADS CSV                            │
│              (e.g., students_2024.csv)                              │
└────────────────────────────────────────────────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────────┐
                │ Dataset Auto-Detection      │
                │                             │
                │ 1. Read CSV file            │
                │ 2. Detect columns          │
                │ 3. Infer data types        │
                │ 4. Identify primary key    │
                │ 5. Mark sensitive columns  │
                └─────────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────────┐
                │ Generate Config JSON        │
                │                             │
                │ {                           │
                │   "dataset_name": "...",    │
                │   "columns": {...},         │
                │   "intents": {...}          │
                │ }                           │
                └─────────────────────────────┘
                              │
                              ↓
        ┌─────────────────────┬─────────────────────┐
        │                     │                     │
        ↓                     ↓                     ↓
┌────────────────┐  ┌──────────────────┐  ┌─────────────────┐
│ Create DB      │  │ Auto-Generate    │  │ Update Intent   │
│ Schema         │  │ Intent Training  │  │ Classifier      │
│ (Dynamic)      │  │ Data             │  │ (Re-train)      │
│                │  │                  │  │                 │
│ CREATE TABLE   │  │ "show my {col}"  │  │ Load new        │
│ students_2024  │  │ "what is my..."  │  │ sentence-       │
│ (with all CSV  │  │ "tell me about..."│ │ transformers    │
│ columns)       │  │                  │  │ model           │
└────────────────┘  └──────────────────┘  └─────────────────┘
        │                     │                     │
        └─────────────────────┼─────────────────────┘
                              │
                              ↓
                    ┌──────────────────┐
                    │ Load Data into   │
                    │ New Database     │
                    │ (from CSV)       │
                    └──────────────────┘
                              │
                              ↓
                    ┌──────────────────┐
                    │ System Ready!    │
                    │ All APIs work    │
                    │ for new dataset  │
                    └──────────────────┘

RESULT: Users can now query the new dataset without any code changes!
```

---

## Intent Classification System

```
┌─────────────────────────────────────────────────────────┐
│         TRAINING PHASE (Setup)                           │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  For each column: [Fees_Details, Email_ID, CGPA...]    │
│  ↓                                                        │
│  Auto-generate variations:                              │
│  • "show my Fees_Details"                              │
│  • "what are my Fees_Details"                          │
│  • "get Fees_Details information"                      │
│  • "Fees_Details status"                               │
│  • "tell me about Fees_Details"                        │
│  • ... (10+ per column)                                │
│  ↓                                                        │
│  Load sentence-transformers model                       │
│  model = SentenceTransformer('all-MiniLM-L6-v2')       │
│  ↓                                                        │
│  Compute embeddings for all training queries            │
│  Store in memory for inference                          │
│                                                           │
└─────────────────────────────────────────────────────────┘
                              │
                              ↓
┌─────────────────────────────────────────────────────────┐
│         INFERENCE PHASE (Runtime)                        │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  User Query: "show me my fees"                          │
│  ↓                                                        │
│  Compute embedding for user query                       │
│  ↓                                                        │
│  Calculate similarity to ALL training examples          │
│  ↓                                                        │
│  Find top match:                                        │
│  • Best match: "show my Fees_Details" (similarity: 0.95)│
│  • 2nd match: "get fee details" (similarity: 0.92)     │
│  ↓                                                        │
│  Detected Column: Fees_Details                          │
│  Confidence: 95%                                        │
│  ↓                                                        │
│  Return column to query handler                         │
│                                                           │
│  COMPARISON WITH OLD SYSTEM:                            │
│  ❌ Old: Check if "fee" or "fees" in text              │
│  ✅ New: Understands "fees", "fee status", "charges",  │
│         "dues", "payment" etc.                          │
│                                                           │
└─────────────────────────────────────────────────────────┘
```

---

## Security Model

```
┌──────────────────────────────────────────────────────────────┐
│                    LOGIN ENDPOINT                             │
│  POST /api/v2/auth/login                                      │
│  {                                                             │
│    "register_number": "REG001",                               │
│    "password": "hashed_password"                              │
│  }                                                             │
└──────────────────────────────────────────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────┐
                │ Verify Credentials      │
                │ 1. Check user exists    │
                │ 2. Hash provided pwd    │
                │ 3. Compare hashes      │
                └─────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────┐
                │ Generate JWT Token      │
                │                         │
                │ Header: {               │
                │   "alg": "HS256"       │
                │ }                       │
                │ Payload: {              │
                │   "user_id": 1,         │
                │   "register_number":    │
                │   "REG001",             │
                │   "dataset_id": 1,      │
                │   "exp": 900,           │
                │   "iat": 1234567890    │
                │ }                       │
                │ Signature: SECRET_KEY   │
                │                         │
                └─────────────────────────┘
                              │
                              ↓
            ┌───────────────────────────────────┐
            │  RETURN TOKEN TO CLIENT            │
            │  {                                 │
            │    "token": "eyJhbGc...",         │
            │    "expires_in": 900,             │
            │    "user": {name, email}          │
            │  }                                 │
            └───────────────────────────────────┘


┌──────────────────────────────────────────────────────────────┐
│              SUBSEQUENT API REQUESTS                          │
│  GET /api/v2/user/data/Fees_Details                          │
│  Headers: {                                                   │
│    "Authorization": "Bearer eyJhbGc..."                      │
│  }                                                             │
└──────────────────────────────────────────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────┐
                │ Extract Token from      │
                │ Authorization Header    │
                └─────────────────────────┘
                              │
                              ↓
                ┌─────────────────────────┐
                │ Verify Token Signature  │
                │ Using SECRET_KEY        │
                │ (Prevent tampering)    │
                └─────────────────────────┘
                              │
        ┌─────────────────────┴────────────────────────┐
        │                                               │
    VALID                                          INVALID
        │                                               │
        ↓                                               ↓
┌─────────────────┐                          Return 401
│ Extract Claims  │                          Unauthorized
│ user_id: 1      │
│ exp: 1234567890 │
└─────────────────┘
        │
        ↓
    ┌─────────────────┐
    │ Check Expiration│
    │ exp > now?      │
    └─────────────────┘
        │
    ┌───┴────┐
    │         │
VALID    EXPIRED
    │         │
    ↓         ↓
Access   Return 401
    │    Token Expired
    ↓
┌──────────────────────┐
│ Verify Data Access   │
│                      │
│ Is user_id = 1?      │
│ Requesting own data? │
│ YES: Proceed         │
│ NO: Return 403       │
│ (Forbidden)          │
└──────────────────────┘
    │
    ↓
┌──────────────────────┐
│ Query Database       │
│ Get Fees_Details for │
│ register_number      │
└──────────────────────┘
    │
    ↓
┌──────────────────────┐
│ Log Access Event     │
│ • user_id: 1        │
│ • column: Fees_...   │
│ • timestamp: ...     │
│ • IP: ...           │
└──────────────────────┘
    │
    ↓
    RETURN DATA
```

---

## Database Schema Design

```
DATABASE: config.db (Metadata)
──────────────────────────────────

TABLE: datasets
┌─────────────────────────────────────┐
│ dataset_id (PK)                     │
│ dataset_name                        │
│ file_path                           │
│ primary_key_column                  │
│ created_at                          │
│ updated_at                          │
└─────────────────────────────────────┘

TABLE: columns
┌─────────────────────────────────────┐
│ column_id (PK)                      │
│ dataset_id (FK)                     │
│ column_name                         │
│ data_type (TEXT, INT, REAL)        │
│ is_sensitive (bool)                 │
│ is_queryable (bool)                 │
│ display_order                       │
└─────────────────────────────────────┘

TABLE: intents
┌─────────────────────────────────────┐
│ intent_id (PK)                      │
│ intent_name                         │
│ intent_type (column_query, etc)    │
│ column_id (FK)  [if column-based]  │
│ training_examples (JSON)            │
└─────────────────────────────────────┘

───────────────────────────────────────

DATABASE: students_2024.db (Actual Data)
────────────────────────────────────────

TABLE: users
┌──────────────────────────────────────┐
│ user_id (PK)                         │
│ register_number (UNIQUE)             │
│ password_hash                        │
│ full_name                            │
│ email                                │
│ created_at                           │
│ last_login                           │
│ is_active (bool)                    │
└──────────────────────────────────────┘

TABLE: student_records
┌──────────────────────────────────────┐
│ record_id (PK)                       │
│ register_number (FK)                 │
│ [DYNAMIC COLUMNS from CSV]           │
│ • Student_Name TEXT                  │
│ • Fees_Details TEXT                  │
│ • Email_ID TEXT                      │
│ • Contact_Number TEXT                │
│ • CGPA REAL                          │
│ • Attendance_Percentage REAL         │
│ • ... (any columns from CSV)         │
└──────────────────────────────────────┘

TABLE: chat_history
┌──────────────────────────────────────┐
│ chat_id (PK)                         │
│ user_id (FK)                         │
│ query (user input)                   │
│ detected_intent                      │
│ target_column                        │
│ response (bot reply)                 │
│ timestamp                            │
└──────────────────────────────────────┘

TABLE: access_log
┌──────────────────────────────────────┐
│ log_id (PK)                          │
│ user_id (FK)                         │
│ action (query, login, access)       │
│ resource_type (column, user_data)   │
│ resource_id                          │
│ timestamp                            │
│ ip_address                           │
│ status (success, denied)             │
└──────────────────────────────────────┘
```

---

## API Endpoint Structure

```
AUTHENTICATION ENDPOINTS
├── POST   /api/v2/auth/login
│          Input: {register_number, password}
│          Output: {token, user_info}
│
├── POST   /api/v2/auth/logout
│          Headers: {Authorization: Bearer token}
│          Output: {success: true}
│
├── POST   /api/v2/auth/refresh
│          Input: {refresh_token}
│          Output: {new_token}
│
└── GET    /api/v2/auth/me
           Headers: {Authorization: Bearer token}
           Output: {user_info, dataset_info}

USER DATA ENDPOINTS
├── GET    /api/v2/user/data
│          Returns all user's data (except sensitive)
│
├── GET    /api/v2/user/data/{column_name}
│          Returns specific column value
│
├── POST   /api/v2/user/query
│          Input: {query: "show my fees"}
│          Output: {intent, column, value}
│
└── GET    /api/v2/user/profile
           Returns user profile information

DATASET MANAGEMENT (Admin only)
├── POST   /api/v2/admin/dataset/upload
│          Input: CSV file
│          Output: {dataset_id, columns_created}
│
├── GET    /api/v2/admin/datasets
│          List all datasets
│
├── GET    /api/v2/admin/dataset/{id}
│          Dataset metadata & statistics
│
└── DELETE /api/v2/admin/dataset/{id}
           Remove dataset

ANALYTICS ENDPOINTS
├── GET    /api/v2/admin/analytics/access-logs
│
├── GET    /api/v2/admin/analytics/user-activity
│
└── GET    /api/v2/admin/analytics/intent-usage
```

---

## UI/UX Flow

```
┌─────────────────────────────────────┐
│     START APPLICATION               │
└─────────────────────────────────────┘
           │
           ↓
┌─────────────────────────────────────┐
│    CHECK JWT TOKEN                  │
│    (in localStorage)                │
└─────────────────────────────────────┘
           │
    ┌──────┴──────┐
    │             │
FOUND        NOT FOUND
    │             │
    ↓             ↓
DASHBOARD    LOGIN PAGE
    │        ┌──────────────┐
    │        │ Register #   │
    │        │ Password     │
    │        │ [Login]      │
    │        └──────────────┘
    │             │
    │             ↓
    │        ┌──────────────┐
    │        │ Verify Creds │
    │        └──────────────┘
    │             │
    │        ┌────┴────┐
    │        │          │
    │      VALID    INVALID
    │        │          │
    │        ↓          ↓
    │    DASHBOARD   Show Error
    │        │        Retry
    │        └────┬─────┘
    │             │
    └─────────────┴────────┐
                           │
                           ↓
                    ┌─────────────────┐
                    │ DASHBOARD       │
                    │                 │
                    │ [Profile Card]  │
                    │ • Name          │
                    │ • Register #    │
                    │ • CGPA: 8.5     │
                    │ • Attendance: 85│
                    │ • Fees: Paid    │
                    │                 │
                    │ [Chat Area]     │
                    │ • Conversation  │
                    │ • Suggestions   │
                    │ • [Input box]   │
                    │                 │
                    │ [Settings]      │
                    │ [Logout]        │
                    └─────────────────┘
```

---

This visual architecture shows how all components connect and work together!

