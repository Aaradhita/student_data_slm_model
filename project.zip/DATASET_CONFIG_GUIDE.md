# 🔄 Dynamic Dataset Configuration Guide

## Overview

The system now supports **ANY dataset** automatically! It dynamically discovers column headers, creates intents, and generates appropriate responses. No hardcoding needed.

---

## Quick Start with Current Dataset

The current configuration works with the student dataset out of the box:

```python
# config.py (already configured)
DATABASE_PATH = "students_2024.db"
DATA_TABLE = "students"
USER_ID_COLUMN = "Register_Number"
USER_NAME_COLUMN = "Student_Name"
```

---

## Setup for Different Datasets

### Option 1: Modify config.py (Simple)

```python
# config.py

class DatasetConfig:
    DATABASE_PATH = "your_database.db"      # Your database file
    DATA_TABLE = "your_table_name"          # Main table with records
    USER_ID_COLUMN = "user_id_column"       # Column that identifies users
    USER_NAME_COLUMN = "user_name_column"   # Column with user names
```

Then restart the server - it automatically detects all columns!

---

### Option 2: Use DatasetConfigBuilder (Programmatic)

Edit `config.py` to change the active configuration:

```python
# At the bottom of config.py

# For custom dataset
ACTIVE_CONFIG = DatasetConfigBuilder.for_custom(
    db_path="company.db",
    data_table="employees",
    id_column="employee_id",
    name_column="employee_name"
)

# Or use pre-built configurations:
# ACTIVE_CONFIG = DatasetConfigBuilder.for_employees("company.db")
# ACTIVE_CONFIG = DatasetConfigBuilder.for_products("inventory.db")
# ACTIVE_CONFIG = DatasetConfigBuilder.for_patients("hospital.db")
```

---

## How It Works

### 1. Schema Discovery
The system automatically:
- Reads all columns from the specified table
- Infers column types (numeric, text, percentage, status, contact, date)
- Generates natural language search terms

### 2. Dynamic Intent Creation
For each column, it creates an intent:
```
Column: CGPA → Intent: "What's my CGPA?"
Column: Contact_Number → Intent: "What's my contact?"
Column: Fees_Status → Intent: "What's my fees status?"
```

### 3. Query Matching
When user asks a question:
- System matches keywords to available columns
- Returns confidence scores
- Selects best match
- Formats response based on column type

---

## API Endpoints for Discovery

### Get Schema Information
```bash
curl http://localhost:8000/api/schema
```

**Response:**
```json
{
  "database": "students_2024.db",
  "table": "students",
  "columns": {
    "CGPA": {
      "type": "numeric",
      "display_name": "Cgpa",
      "natural_names": ["cgpa", "gpa", "grade"]
    },
    "Contact_Number": {
      "type": "contact",
      "display_name": "Contact Number",
      "natural_names": ["contact", "phone", "number"]
    }
    // ... more columns
  },
  "searchable_columns": [
    "Student_Name", "Fees_Details", "CGPA", ...
  ]
}
```

### Get Available Intents
```bash
curl http://localhost:8000/api/intents
```

**Response:**
```json
{
  "available_intents": {
    "cgpa": "Cgpa",
    "contact_number": "Contact Number",
    "fees_details": "Fees Details",
    "attendance_percentage": "Attendance Percentage"
  },
  "count": 14,
  "examples": [
    "What's my Cgpa?",
    "What's my Contact Number?",
    "What's my Fees Details?",
    "What's my Attendance Percentage?",
    "What's my Books Borrowed?"
  ]
}
```

---

## Examples: Setting Up Different Datasets

### Example 1: Employee Dataset

**Database Structure:**
```
employees table:
- employee_id (unique identifier)
- employee_name
- salary
- department
- hire_date
- email
- performance_score
```

**Setup:**
```python
# config.py
class DatasetConfig:
    DATABASE_PATH = "company.db"
    DATA_TABLE = "employees"
    USER_ID_COLUMN = "employee_id"
    USER_NAME_COLUMN = "employee_name"
```

**Auto-Generated Intents:**
- "What's my salary?"
- "What's my department?"
- "What's my performance score?"
- "What's my email?"

---

### Example 2: Hospital Patient Dataset

**Database Structure:**
```
patients table:
- patient_id
- patient_name
- blood_type
- allergies
- medications
- appointment_date
- doctor_name
```

**Setup:**
```python
# config.py
class DatasetConfig:
    DATABASE_PATH = "hospital.db"
    DATA_TABLE = "patients"
    USER_ID_COLUMN = "patient_id"
    USER_NAME_COLUMN = "patient_name"
```

**Auto-Generated Intents:**
- "What's my blood type?"
- "What are my allergies?"
- "What medications am I on?"
- "When is my appointment?"

---

### Example 3: E-Commerce Product Dataset

**Database Structure:**
```
products table:
- product_id
- product_name
- price
- stock_quantity
- category
- supplier_name
- rating
```

**Setup:**
```python
# config.py
class DatasetConfig:
    DATABASE_PATH = "shop.db"
    DATA_TABLE = "products"
    USER_ID_COLUMN = "product_id"
    USER_NAME_COLUMN = "product_name"
```

**Auto-Generated Intents:**
- "What's the price?"
- "How much stock?"
- "What category?"
- "Who's the supplier?"

---

## Advanced Configuration

### Custom Column Mappings

If some columns are hard to identify:

```python
# config.py
CUSTOM_COLUMN_MAPPINGS = {
    "salary": "annual_salary",
    "phone": "contact_phone_number",
    "address": "residential_address"
}
```

### Column Type Hints

If auto-detection fails:

```python
# config.py
COLUMN_TYPE_HINTS = {
    "special_rating": "numeric",
    "status_code": "status",
    "mobile": "contact"
}
```

### Priority Columns

Define which columns to match first:

```python
# config.py
PRIORITY_COLUMNS = [
    "salary",
    "department",
    "performance_score"
]
```

---

## Testing Your Dataset Setup

### 1. Check Schema is Detected
```bash
curl http://localhost:8000/api/schema | python -m json.tool
```

### 2. Check Available Intents
```bash
curl http://localhost:8000/api/intents | python -m json.tool
```

### 3. Test a Query
```bash
# Get token first
TOKEN=$(curl -X POST http://localhost:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{"register_number":"USER_ID","password":"password"}' \
  | jq -r '.access_token')

# Send query
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"message":"What is my key_field?"}'
```

---

## How to Use with New Dataset

### Step 1: Create Database
```python
import sqlite3

conn = sqlite3.connect("my_database.db")
cursor = conn.cursor()

# Create your table
cursor.execute("""
    CREATE TABLE my_data (
        id PRIMARY KEY,
        name TEXT,
        field1 TEXT,
        field2 NUMERIC,
        ...
    )
""")

# Insert data
cursor.execute("INSERT INTO my_data VALUES (...)")
conn.commit()
conn.close()
```

### Step 2: Update config.py
```python
# config.py
class DatasetConfig:
    DATABASE_PATH = "my_database.db"
    DATA_TABLE = "my_data"
    USER_ID_COLUMN = "id"
    USER_NAME_COLUMN = "name"
```

### Step 3: Update Authentication
Update the users table if using different auth:
```python
# auth/auth_service.py - make sure users can login
```

### Step 4: Restart Server
```bash
python app.py
```

### Step 5: Test
```bash
curl http://localhost:8000/api/schema
curl http://localhost:8000/api/intents
```

---

## Key Files

| File | Purpose |
|------|---------|
| `config.py` | Dataset configuration |
| `schema_discovery.py` | Auto-detects columns and types |
| `dynamic_intent.py` | Processes queries dynamically |
| `app.py` | Updated to use dynamic system |

---

## What Gets Reused?

✅ **Automatically Reusable Across Datasets:**
- Authentication system (same login/token system)
- API structure (same endpoints)
- Chat interface (same frontend)
- Query matching logic (works with any columns)
- Response formatting (adapts to column types)

❌ **What Stays the Same:**
- User authentication mechanism
- Database schema structure (still relational)
- API response format

---

## Troubleshooting

### "Column not found" error
- Check `USER_ID_COLUMN` matches actual database column
- Verify table name in `DATA_TABLE`
- Run `curl http://localhost:8000/api/schema` to see actual columns

### Intents not appearing
- Check columns are in the table
- Verify columns aren't being filtered out (system excludes ID/timestamp columns)
- See `get_searchable_columns()` in schema_discovery.py

### Queries not matching
- Check query keywords match column names
- Use `/api/intents` to see expected search terms
- Try simpler queries first

---

## Ready to Use!

Just change the config and restart - the entire system adapts automatically! 🚀

No more hardcoding, no more rebuilding. **Pure, reusable magic.** ✨
