## Project Overview

Small RAG / intent-classification project that includes tooling to build
a vector index (FAISS), lightweight intent classifiers, and small FastAPI
endpoints for demo/testing.

## Prerequisites

- Python 3.10+ (project virtual environment is in `provenv/`)
- Git (optional)

## Installation

1. Activate the virtual environment on Windows:

```powershell
.\provenv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

If you want an exact environment from your current venv, run `pip freeze > requirements_full.txt`.

Alternatively, to install the fully-pinned environment that matches the provided
`provenv/` virtualenv, run:

```powershell
.\provenv\Scripts\activate
pip install -r requirements_full.txt
```

## Files of interest

- `stage4/` — RAG pipeline and index builder (`build_index.py`, `rag_pipeline.py`)
- `stage4/chat.py` — small chat wrapper that uses `rag_pipeline`
- `stage3_api.py` — example FastAPI endpoint for simple lookups
- `stage5_chat_api.py` — FastAPI app that serves a simple chat UI (uses templates)
- `embedding_intent_classifier.py`, `slm_intent_model.py` — intent classifier code

## Running the project

- Build / run the RAG pipeline (stage 4):

```bash
python -u stage4/rag_pipeline.py
```

- Run the simple API (stage 3) with Uvicorn (recommended for development):

```bash
uvicorn stage3_api:app --reload
```

- Run the chat API (stage 5) with Uvicorn:

```bash
uvicorn stage5_chat_api:app --reload
```

## Dependencies

See `requirements.txt` for the main packages used in the project (FastAPI,
scikit-learn, FAISS, pandas, numpy, etc.).

## Notes

- If you add or upgrade packages, regenerate `requirements.txt` or create a
   new pinned file with `pip freeze`.
- `requirements_full.txt` — fully pinned environment generated from `provenv`.
- If you want, I can also create `requirements-dev.txt` with test and lint
   tools or generate a fully-pinned `requirements_full.txt` from the venv.

## Contributing

1. Fork the repository.
2. Create a new branch (`git checkout -b feature-branch`).
3. Make your changes and commit them.
4. Push to your branch and open a pull request.

## License

This project is under the MIT License (if a `LICENSE` file exists).
