from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, Dict, List
import sqlite3
import json
from datetime import datetime
from auth.auth_service import AuthService
from auth.password_utils import PasswordManager
from config import ACTIVE_CONFIG
from dynamic_intent import DynamicIntentProcessor
import os

app = FastAPI(title="Student Portal API v2", version="2.0.0")

# Serve static files
app.mount("/static", StaticFiles(directory="templates"), name="static")

# Database configuration
DB_PATH = ACTIVE_CONFIG.DATABASE_PATH
DATA_TABLE = ACTIVE_CONFIG.DATA_TABLE
auth_service = AuthService(DB_PATH)

# Initialize dynamic intent processor
intent_processor = DynamicIntentProcessor(DB_PATH, DATA_TABLE)

# ==================== PYDANTIC MODELS ====================

class LoginRequest(BaseModel):
    register_number: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: Dict

class RegisterRequest(BaseModel):
    register_number: str
    password: str
    full_name: str
    email: str

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    intent: str
    data: Optional[Dict] = None

# ==================== AUTHENTICATION ====================

def verify_token(token: str) -> dict:
    """Verify JWT token"""
    if not token.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token format"
        )
    
    token = token.replace("Bearer ", "")
    payload = auth_service.verify_token(token)
    
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired or invalid"
        )
    
    return payload

async def get_current_user(request: Request) -> dict:
    """Get current authenticated user from Authorization header"""
    auth_header = request.headers.get("Authorization")
    
    if not auth_header:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token"
        )
    
    return verify_token(auth_header)

# ==================== AUTH ENDPOINTS ====================

@app.post("/api/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    """Login endpoint"""
    user = auth_service.login(request.register_number, request.password)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid register number or password"
        )
    
    access_token, expires_in = auth_service.create_access_token(
        user_id=1,  # Simplified for now
        register_number=user['register_number']
    )
    
    return LoginResponse(
        access_token=access_token,
        expires_in=expires_in,
        user=user
    )

@app.post("/api/register")
async def register(request: RegisterRequest):
    """Register new user"""
    success = auth_service.register_user(
        register_number=request.register_number,
        password=request.password,
        full_name=request.full_name,
        email=request.email
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Register number already exists"
        )
    
    return {"message": "User registered successfully"}

# ==================== CHAT ENDPOINT ====================

def get_student_data(register_number: str) -> Dict:
    """Get student data from database"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # Use config to find the correct column
        id_column = ACTIVE_CONFIG.USER_ID_COLUMN
        cursor.execute(f"SELECT * FROM {DATA_TABLE} WHERE {id_column} = ?", (register_number,))
        record = cursor.fetchone()
        
        if record:
            return dict(record)
        return None
    finally:
        conn.close()

def process_intent(message: str, user_data: Dict, register_number: str) -> tuple:
    """
    Dynamic intent classification using schema discovery.
    Works with any dataset automatically.
    """
    # Use the dynamic intent processor
    response, matched_intent, matched_columns = intent_processor.process_query(
        message, 
        user_data if user_data else {}
    )
    
    return response, matched_intent

@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest, current_user: dict = Depends(get_current_user)):
    """Chat endpoint - process queries using dynamic intent system"""
    register_number = current_user.get('register_number')
    
    # Get user data
    user_data = get_student_data(register_number)
    
    # Process intent and generate response using dynamic processor
    response, intent = process_intent(request.message, user_data, register_number)
    
    return ChatResponse(
        response=response,
        intent=intent,
        data=user_data
    )

# ==================== DATA ENDPOINTS ====================

@app.get("/api/user/profile")
async def get_profile(current_user: dict = Depends(get_current_user)):
    """Get current user profile"""
    register_number = current_user.get('register_number')
    student_data = get_student_data(register_number)
    
    if not student_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    
    return {
        "register_number": register_number,
        "user": current_user,
        "academic_data": student_data
    }

@app.get("/api/user/data/{column}")
async def get_column_data(column: str, current_user: dict = Depends(get_current_user)):
    """Get specific column data"""
    register_number = current_user.get('register_number')
    student_data = get_student_data(register_number)
    
    if not student_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    
    if column not in student_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Column '{column}' not found"
        )
    
    return {
        "column": column,
        "value": student_data.get(column)
    }

# ==================== FILE SERVING ====================

@app.get("/")
async def serve_root():
    """Serve login page as root"""
    return FileResponse("templates/login.html", media_type="text/html")

@app.get("/login.html")
async def serve_login():
    """Serve login page"""
    return FileResponse("templates/login.html", media_type="text/html")

@app.get("/dashboard.html")
async def serve_dashboard():
    """Serve dashboard page"""
    return FileResponse("templates/dashboard.html", media_type="text/html")

# ==================== HEALTH CHECK ====================

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "online",
        "version": "2.0.0",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/schema")
async def get_schema():
    """Get available schema and columns for current dataset"""
    from schema_discovery import SchemaDiscovery
    schema = SchemaDiscovery(DB_PATH)
    metadata = schema.get_column_metadata(DATA_TABLE)
    
    return {
        "database": DB_PATH,
        "table": DATA_TABLE,
        "columns": metadata,
        "searchable_columns": list(intent_processor.searchable_columns.keys())
    }

@app.get("/api/intents")
async def get_available_intents():
    """Get all available intents based on columns"""
    intents = intent_processor.get_available_intents()
    
    return {
        "available_intents": intents,
        "count": len(intents),
        "examples": [
            f"What's my {display}?" 
            for display in list(intents.values())[:5]
        ]
    }

if __name__ == "__main__":
    import uvicorn
    
    # Initialize database
    from database_init import initialize_database
    initialize_database()
    
    print("\n" + "="*60)
    print("[*] Student Portal API v2 Starting...")
    print("="*60)
    print("[+] Authentication enabled")
    print("[+] Database initialized")
    print("[+] JWT tokens active")
    print("="*60)
    print("\n[INFO] Test Login Credentials:")
    print("   Register: DEMO001")
    print("   Password: demo@123")
    print("\n[INFO] Access at: http://localhost:8000")
    print("="*60 + "\n")
    
    try:
        uvicorn.run(app, host="0.0.0.0", port=8000)
    except OSError:
        print("Port 8000 is busy, trying 8001...")
        uvicorn.run(app, host="0.0.0.0", port=8001)
