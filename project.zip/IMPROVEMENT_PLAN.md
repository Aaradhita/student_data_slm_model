# 🚀 Project Enhancement Plan - Dynamic Multi-Dataset Chatbot System

## Current Issues Identified

### 1. **Manual Column Hardcoding**
   - Database schema is hardcoded in `create_table.py`
   - APIs in `stage3_api.py` have hardcoded endpoints for each column
   - Intent data is manually created in `intent_data.csv`
   - Any new dataset requires code changes

### 2. **Limited Intent Recognition**
   - Only keyword-based detection in `stage5_chat_api.py` (hardcoded checks)
   - Limited to ~5-6 intents (fees, attendance, academic, scholarship)
   - No NLP understanding of varied query patterns

### 3. **No User Authentication**
   - All users can query any student data (privacy issue)
   - No login system
   - No session management

### 4. **Poor UI/UX**
   - Basic HTML template
   - No professional dashboard
   - No user profile display
   - Limited visual feedback

### 5. **Hardcoded Mapping**
   - Intent → API endpoint mapping is manual
   - Column selection is hardcoded

---

## 🎯 Proposed Solution Architecture

### **Phase 1: Dynamic Database & Intent System**

#### 1.1 Dataset Configuration Framework
```
config/
  ├── dataset_config.json      # User-defined dataset metadata
  └── intent_templates.json    # Dynamic intent generation rules
```

**Features:**
- Auto-detect CSV columns
- Dynamically create DB schema
- Auto-generate intent training data
- Support multiple dataset types (student, employee, patient, etc.)

#### 1.2 Dynamic Intent Classification
- Upgrade from TF-IDF to a more sophisticated model:
  - Use `sentence-transformers` for semantic similarity
  - Add support for domain-specific intents
  - Auto-train on dataset columns

**New Intent Categories:**
```
- Column-based: "show my {column}" (fees, attendance, email, contact)
- Aggregate: "average {column}", "compare {column}"
- Status: "what's my {column} status"
- Details: "detailed {column} information"
- Time-based: "my {column} over time", "my {column} history"
```

---

### **Phase 2: Authentication & Privacy**

#### 2.1 User Login System
```
auth/
  ├── models.py           # User/Student data models
  ├── auth_service.py     # JWT token generation
  ├── password_utils.py   # Hashing & verification
  └── middleware.py       # Auth middleware for APIs
```

**Flow:**
1. User enters Register_Number + Password
2. Verify against database
3. Generate JWT token
4. Token sent in API requests
5. Middleware verifies token before data access

#### 2.2 Data Access Control
- Each user can ONLY access their own record
- All APIs require authentication token
- Audit logging for data access

---

### **Phase 3: Enhanced UI/UX**

#### 3.1 Modern Dashboard
```
frontend/
  ├── pages/
  │   ├── login.html          # Login page
  │   ├── dashboard.html      # User dashboard
  │   ├── chat.html           # Chat interface
  │   └── profile.html        # User profile
  ├── css/
  │   ├── styles.css          # Global styles
  │   └── chat-theme.css      # Chat styling
  └── js/
      ├── auth.js             # Auth logic
      └── chat.js             # Chat interactions
```

**Features:**
- Professional login page with branding
- User profile card displaying key info
- Chat sidebar with conversation history
- Dark mode support
- Mobile-responsive design
- Real-time chat updates

#### 3.2 Dashboard Components
- User profile with quick stats
- Chat history
- Available query suggestions
- Data visualization (CGPA trend, attendance graph, etc.)

---

### **Phase 4: Scalable Architecture**

#### 4.1 Database Enhancement
```python
# Two-tier approach:
1. Config Database (config.db)
   - Dataset metadata
   - Column definitions
   - Intent mappings
   
2. Data Database (dynamic based on dataset_name.db)
   - Student/Employee/Patient records
   - User credentials
   - Chat history
```

#### 4.2 API Restructuring
```
API Endpoints (v2):
├── /api/v2/auth/
│   ├── POST /login          # Login
│   ├── POST /logout         # Logout
│   ├── POST /refresh        # Refresh token
│   └── GET  /me             # Current user info
├── /api/v2/user/
│   ├── GET  /data           # Get own data
│   ├── GET  /column/{col}   # Get specific column
│   └── POST /query          # Natural language query
├── /api/v2/admin/
│   ├── POST /dataset/upload # Upload new dataset
│   ├── GET  /datasets       # List datasets
│   └── DELETE /dataset/{id} # Remove dataset
└── /api/v2/chat/
    ├── GET  /message        # Send message
    └── GET  /history        # Get chat history
```

---

## 📋 Implementation Roadmap

### **Week 1: Foundation**
- [ ] Create configuration framework
- [ ] Implement dataset auto-detection
- [ ] Dynamic DB schema generation
- [ ] Auto-generate intent training data

### **Week 2: Authentication**
- [ ] User database schema
- [ ] Login API endpoint
- [ ] JWT token system
- [ ] Auth middleware

### **Week 3: Dynamic APIs**
- [ ] Refactor Stage 3 API for dynamic columns
- [ ] Implement access control
- [ ] Auto-generate endpoints from config
- [ ] Query validation

### **Week 4: Advanced Intent System**
- [ ] Upgrade intent classifier
- [ ] Support custom intent templates
- [ ] Multi-intent queries
- [ ] Semantic similarity matching

### **Week 5: Enhanced UI/UX**
- [ ] Design login page
- [ ] Build dashboard
- [ ] Implement chat interface
- [ ] Add data visualization

### **Week 6: Testing & Optimization**
- [ ] Unit tests for all modules
- [ ] Integration tests
- [ ] Performance optimization
- [ ] Security audit

---

## 🔧 Key Technical Components

### **1. Dynamic Intent Generator**
```python
# Auto-generate intents from columns
Intent patterns:
- "show me my {column}"
- "what is my {column}"
- "get {column} details"
- "{column} status"
- "my {column} information"

For each column in dataset:
- Generate 10-15 example queries
- Create training data automatically
```

### **2. Semantic Intent Classifier**
```python
# Replace TF-IDF with sentence-transformers
Model: "all-MiniLM-L6-v2"
Benefits:
- Understands semantic meaning
- Better performance on varied phrasings
- Can handle new intents with few examples
```

### **3. Dynamic API Generator**
```python
# Auto-create endpoints from config
For each column:
  - GET /user/{column}
  - GET /user/column/{name}
  - POST /user/query (natural language)
```

### **4. Session & Privacy System**
```python
# JWT-based authentication
Claims:
- user_id
- register_number
- dataset_id
- permissions

Middleware:
- Verify token
- Check data ownership
- Log access
```

---

## 📊 Data Models

### **Configuration (config.json)**
```json
{
  "dataset_name": "students_2024",
  "primary_key": "Register_Number",
  "display_columns": ["Student_Name", "Email_ID", "Attendance_Percentage"],
  "query_columns": ["Fees_Details", "CGPA", "Scholarship_Eligibility"],
  "sensitive_columns": ["Contact_Number", "Date_of_Birth"],
  "intents": {
    "fee_enquiry": ["fees", "payment", "charges", "dues"],
    "attendance": ["attendance", "absences", "presence"],
    "academic": ["cgpa", "grades", "marks", "academic"],
    "contact": ["contact", "phone", "email", "reach"]
  }
}
```

### **User Authentication (DB)**
```sql
CREATE TABLE users (
  user_id INTEGER PRIMARY KEY,
  register_number TEXT UNIQUE,
  password_hash TEXT,
  full_name TEXT,
  email TEXT,
  last_login TIMESTAMP,
  created_at TIMESTAMP
);

CREATE TABLE chat_history (
  chat_id INTEGER PRIMARY KEY,
  user_id INTEGER,
  query TEXT,
  intent TEXT,
  response TEXT,
  timestamp TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(user_id)
);
```

---

## 🔐 Security Measures

1. **Password Hashing**: Use bcrypt for password storage
2. **JWT Tokens**: Implement token expiration (15 min access, 7 day refresh)
3. **Rate Limiting**: Limit API requests per user
4. **Access Logging**: Log all data access attempts
5. **Input Validation**: Sanitize all user inputs
6. **HTTPS Only**: Deploy with SSL/TLS
7. **CORS**: Restrict to same-origin

---

## 🎨 UI/UX Improvements

### **Login Page**
- Professional design with gradient background
- Remember me option
- Forgot password link
- Terms & privacy checkbox

### **Dashboard**
- User profile card (photo, name, register number)
- Quick stats (CGPA, Attendance, Fees Status)
- Recent queries
- Profile settings

### **Chat Interface**
- Message bubbles (user vs bot)
- Suggested queries
- Chat history sidebar
- Dark mode toggle
- Export conversation

### **Data Visualization**
- Line charts for attendance trends
- Pie charts for fee breakdown
- Progress bars for CGPA comparison
- Timeline for important dates

---

## 📦 New Project Structure

```
project_final/
├── config/
│   ├── dataset_config.json
│   └── intent_templates.json
├── auth/
│   ├── models.py
│   ├── auth_service.py
│   ├── password_utils.py
│   └── middleware.py
├── database/
│   ├── db_init.py
│   ├── db_utils.py
│   └── migrations.py
├── intent/
│   ├── intent_classifier.py
│   ├── intent_generator.py
│   └── intent_data/
├── api/
│   ├── stage3_api.py (refactored)
│   ├── stage5_chat_api.py (refactored)
│   ├── auth_endpoints.py
│   └── admin_endpoints.py
├── frontend/
│   ├── pages/
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   └── chat.html
│   ├── css/
│   └── js/
├── utils/
│   ├── validators.py
│   ├── logger.py
│   └── helpers.py
├── tests/
│   ├── test_auth.py
│   ├── test_api.py
│   └── test_intent.py
├── main.py
├── requirements.txt
└── .env.example
```

---

## ✅ Expected Benefits

| Aspect | Before | After |
|--------|--------|-------|
| **Dataset Support** | 1 hardcoded | Unlimited dynamic |
| **Intent Types** | 5-6 manual | 20+ auto-generated |
| **Security** | None | Full auth & privacy |
| **Columns** | Fixed 13 | Any number dynamic |
| **UI/UX** | Basic CLI/HTML | Modern dashboard |
| **Scalability** | Poor | Enterprise-ready |
| **Maintenance** | High | Low |
| **User Experience** | Basic | Professional |

---

## 🚀 Quick Win Priorities

**Immediate (Week 1-2):**
1. Add login page & authentication
2. Improve UI with CSS
3. Add user profile display

**Short-term (Week 3-4):**
1. Dynamic intent generation
2. Dynamic API endpoints
3. Multi-intent support

**Medium-term (Week 5-6):**
1. Dataset upload system
2. Advanced analytics
3. Admin dashboard

---

## 📞 Questions to Finalize Plan

1. **Deployment Target**: Cloud (Azure/AWS), On-premise, or Local?
2. **Database Size**: How many users/records expected?
3. **Response Time**: Any SLA requirements?
4. **Integration Needs**: Any existing systems to integrate?
5. **Maintenance**: Who will manage datasets and updates?

---

**Status**: Ready for implementation
**Estimated Timeline**: 4-6 weeks for full implementation
**Risk Level**: Low (incremental approach)
**Resource Requirement**: 1 senior developer

